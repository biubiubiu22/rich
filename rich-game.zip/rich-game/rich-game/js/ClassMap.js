//地图类
function MapView(mapDataArray, width, height, scale, offsetX, offsetY, image, bgImage) {
	this.mapDataArray = mapDataArray;
	this.scale = scale;
	this.offsetX = offsetX;
	this.offsetY = offsetY;

	this.image = image;
	this.widthNum = mapDataArray[0].length; //地图宽的元素数量
	this.heightNum = mapDataArray.length; //地图高的元素数量

	this.width = width; //绘制的地图宽度
	this.height = height; //绘制的地图高度

	this.sw = 200; //绘制出的图像宽度
	this.sw = 100; //绘制出的图像宽度
	this.sh = 100; //绘制出的图像高度	

	if (bgImage) {
		this.drawBgByImage(bgImage);
	}

	// 创建canvas，并初始化 （也可以直接以标签形式写在页面中，然后通过id等方式取得canvas）
	this.canvas = document.createElement("canvas");
	this.canvas.width = this.width;
	this.canvas.height = this.height;
	document.body.appendChild(this.canvas);
	// 取得2d绘图上下文 
	this.context = this.canvas.getContext("2d");
	this.color = '#000000';

	var mapElementArray = new Array();
	var dw = this.sw * this.scale; //绘制出的图像宽度
	var dh = this.sh * this.scale; //绘制出的图像高度	
	for (var i = 0; i < this.heightNum; i++) {
		var tempArray = new Array(0);
		for (var j = 0; j < this.widthNum; j++) {
			var flag = this.mapDataArray[i][j];
			var dx = this.offsetX + j * dw;
			var dy = this.offsetY + i * dh;	//console.log('flag:'+flag+'owner:'+owner+'|sx:'+sx+'|sy:'+sy+'|sw:'+sw+'|sh:'+sh+'|dx:'+dx+'|dy:'+dy+'|scale:'+this.scale+'|image:'+this.image+'|context:'+this.context+'|color:'+this.color);
			tempArray[j] = new MapElement(flag, dx, dy, this.scale, this.image, this.context, this.color);
		}
		mapElementArray[i] = tempArray;
	}
	this.mapElementArray = mapElementArray;
};

MapView.prototype.getijByIndex = function (index) {
	if (index >= 1 && index <= 16) {
		var i = 0;
		var j = index + 1;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 18 && index <= 21) {
		var i = index - 16;
		var j = 19;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 23 && index <= 25) {
		var i = 4;
		var j = 39 - index;
		return {
			'i': i,
			'j': j
		}
	} 
	else if (index >= 30 && index <= 32) {
		var j = 18;
		var i = index - 23;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 33 && index <= 38) {
		var j = 49 - index;
		var i = 10;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 40 && index <= 42) {
		var j = 51 - index;
		var i = 6;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 43 && index <= 44) {
		var j = 51 - index;
		var i = 8;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 46 && index <= 47) {
		var j = 53 - index;
		var i = 4;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 48 && index <= 50) {
		var j = 4;
		var i = index - 43;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 51 && index <= 52) {
		var j = 6;
		var i = index - 43;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 53 && index <= 55) {
		var j = 57 - index;
		var i = 10;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 57 && index <= 59) {
		var j = 3;
		var i = 64 - index;
		return {
			'i': i,
			'j': j
		}
	} else if (index >= 60 && index <= 63) {
		var j = 0;
		var i = 65 - index;
		return {
			'i': i,
			'j': j
		}
	}
};

MapView.prototype.draw = function () {
	for (var i = 0; i < this.heightNum; i++) {
		for (var j = 0; j < this.widthNum; j++) {
			var element = this.mapElementArray[i][j];
			element.draw();
		}
	}
};

MapView.prototype.drawByIndex = function (index) {
	var temp = this.getijByIndex(index);
	if (temp) {
		var i = temp.i;
		var j = temp.j;
		this.mapElementArray[i][j].draw();
	}
};

MapView.prototype.drawBgByImage = function (bgImage) {
	var canvas = document.createElement("canvas");
	canvas.width = this.width;
	canvas.height = this.height;
	document.body.appendChild(canvas);
	var context = canvas.getContext("2d");
	context.drawImage(bgImage, 0, 0, this.width, this.height);
};

MapView.prototype.cleanByColorByIndex = function (index) {
	var temp = this.getijByIndex(index);
	var i = temp.i;
	var j = temp.j;
	this.mapElementArray[i][j].cleanByColor();
};

MapView.prototype.setMap = function (index, flag, owner) {
	console.log(index, flag, owner);

	var temp = this.getijByIndex(index);
	if (temp) {
		var i = temp.i;
		var j = temp.j;
		this.mapElementArray[i][j].setFlag(flag);

		if (owner) {
			this.mapElementArray[i][j].setOwner(owner);
		}
	};
};

MapView.prototype.getMapByIndex = function (index) {
	var temp = this.getijByIndex(index);
	if (temp) {
		var m = temp.i;
		var n = temp.j;
		var flag = this.mapElementArray[m][n].getFlag();
		var owner = this.mapElementArray[m][n].getOwner();
	};
	var i;
	var j;
	if (index >= 0 && index <= 17) {
		i = 1;
		j = index + 1;
	} else if (index >= 17 && index <= 21) {
		i = index - 16;
		j = 18;
	} else if (index >= 21 && index <= 25) {
		i = 5;
		j = 39 - index;
	} else if (index >= 25 && index <= 27) {
		j = 14;
		i = index - 20;
	} else if (index >= 27 && index <= 30) {
		i = 7;
		j = index - 13;
	} else if (index >= 30 && index <= 32) {
		j = 17;
		i = index - 23;
	} else if (index >= 32 && index <= 38) {
		j = 49 - index;
		i = 9;
	} else if (index >= 38 && index <= 40) {
		j = 11;
		i = 47 - index;
	} else if (index >= 40 && index <= 44) {
		j = 51 - index;
		i = 7;
	} else if (index >= 44 && index <= 46) {
		j = 7;
		i = 51 - index;
	} else if (index >= 46 && index <= 48) {
		j = 53 - index;
		i = 5;
	} else if (index >= 48 && index <= 52) {
		j = 5;
		i = index - 43;
	} else if (index >= 52 && index <= 55) {
		j = 57 - index;
		i = 9;
	} else if (index >= 55 && index <= 59) {
		j = 2;
		i = 64 - index;
	} else if (index >= 59 && index <= 60) {
		j = 61 - index;
		i = 5;
	} else if (index >= 60 && index <= 64) {
		j = 1;
		i = 65 - index;
	}
	var x = this.mapElementArray[i][j].dx;
	var y = this.mapElementArray[i][j].dy;
	return {
		'flag': flag,
		'owner': owner,
		'x': x,
		'y': y
	};
};
