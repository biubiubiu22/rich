/**
	new Grid(index, type)
	new Person(userId, index)
	new Block(index)

	couldBeBLocked(index, offset)
	enoughToBuy(index, userId)
	enoughToUpgrad(index, userId)
	enoughToCost(index,userId)
	hasBlock(userId)

	MapView.set(index, type)
	PersonView.init(userId, index)
	PersonView.move(userId, index)
	BlockView.add(index)
	BlockView.remove(index)
	ExtraView.addPerson(userId)
	ExtraView.setMoney(userId, money)
	ExtraView.confirm(userId, index, type, money)
	ExtraView.setBlockCount(userId, count)
	ExtraView.setUserStatus(userId, config)
	ExtraView.gameover(userId)
 */

var CONFIG = {
	'map':[
		{'index':0, 'type':'empty', 'owner':''},
		{'index':1, 'type':'house', 'owner':''},
		{'index':2, 'type':'house', 'owner':''},
		{'index':3, 'type':'house', 'owner':''},
		{'index':4, 'type':'hospital', 'owner':''},
		{'index':5, 'type':'park', 'owner':''},
		{'index':6, 'type':'house', 'owner':''},
		{'index':7, 'type':'house', 'owner':''},
		{'index':8, 'type':'house', 'owner':''},
		{'index':9, 'type':'bigBank', 'owner':''},
		{'index':10, 'type':'bigBank', 'owner':''},
		{'index':11, 'type':'bigBank', 'owner':''},
		{'index':12, 'type':'house', 'owner':''},
		{'index':13, 'type':'house', 'owner':''},
		{'index':14, 'type':'house', 'owner':''},
		{'index':15, 'type':'park', 'owner':''},
		{'index':16, 'type':'house', 'owner':''},
		{'index':17, 'type':'empty', 'owner':''},
		{'index':18, 'type':'casinos', 'owner':''},
		{'index':19, 'type':'house', 'owner':''},
		{'index':20, 'type':'house', 'owner':''},
		{'index':21, 'type':'house', 'owner':''},
		{'index':22, 'type':'empty', 'owner':''},
		{'index':23, 'type':'house', 'owner':''},
		{'index':24, 'type':'house', 'owner':''},
		{'index':25, 'type':'house', 'owner':''},
		{'index':26, 'type':'bank', 'owner':''},
		{'index':27, 'type':'empty', 'owner':''},
		{'index':28, 'type':'shoppingMall', 'owner':''},
		{'index':29, 'type':'park', 'owner':''},
		{'index':30, 'type':'house', 'owner':''},
		{'index':31, 'type':'house', 'owner':''},
		{'index':32, 'type':'house', 'owner':''},
		{'index':33, 'type':'house', 'owner':''},
		{'index':34, 'type':'house', 'owner':''},
		{'index':35, 'type':'park', 'owner':''},
		{'index':36, 'type':'house', 'owner':''},
		{'index':37, 'type':'house', 'owner':''},
		{'index':38, 'type':'house', 'owner':''},
		{'index':39, 'type':'shoppingMall', 'owner':''},
		{'index':40, 'type':'house', 'owner':''},
		{'index':41, 'type':'house', 'owner':''},
		{'index':42, 'type':'house', 'owner':''},
		{'index':43, 'type':'casinos', 'owner':''},
		{'index':44, 'type':'house', 'owner':''},
		{'index':45, 'type':'hospital', 'owner':''},
		{'index':46, 'type':'house', 'owner':''},
		{'index':47, 'type':'house', 'owner':''},
		{'index':48, 'type':'house', 'owner':''},
		{'index':49, 'type':'park', 'owner':''},
		{'index':50, 'type':'house', 'owner':''},
		{'index':51, 'type':'shoppingMall', 'owner':''},
		{'index':52, 'type':'house', 'owner':''},
		{'index':53, 'type':'house', 'owner':''},
		{'index':54, 'type':'house', 'owner':''},
		{'index':55, 'type':'park', 'owner':''},
		{'index':56, 'type':'shoppingMall', 'owner':''},
		{'index':57, 'type':'house', 'owner':''},
		{'index':58, 'type':'house', 'owner':''},
		{'index':59, 'type':'casinos', 'owner':''},
		{'index':60, 'type':'house', 'owner':''},
		{'index':61, 'type':'house', 'owner':''},
		{'index':62, 'type':'house', 'owner':''},
		{'index':63, 'type':'house', 'owner':''},
	],
	'house':[
		{'level':0, 'price':1000, 'charge':1000,'bank':2000,'bigBank':4000},
		{'level':1, 'price':1000, 'charge':2000,'bank':2000,'bigBank':4000},
		{'level':2, 'price':1100, 'charge':3000,'bank':2000,'bigBank':4000},
		{'level':3, 'price':1200, 'charge':5000,'bank':2000,'bigBank':4000}
	],
	'player':[
		{'id':1, 'balance':70000, 'blockNumber': 3, index: 0,'strength':100,'action':1},
		{'id':2, 'balance':70000, 'blockNumber': 3, index: 7,'strength':100,'action':0}
	],
	'timeout_seconds':30
}
